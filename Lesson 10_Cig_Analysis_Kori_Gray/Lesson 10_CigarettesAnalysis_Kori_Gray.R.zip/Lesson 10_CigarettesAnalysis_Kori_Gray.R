#load ggplot2 library and dplyr
library(ggplot2)
library(dplyr)


# install Ecdat package,  load the library. last load the data frame
install.packages("Ecdat")
library(Ecdat)

head(Cigarette)

 #Create a boxplot of the average number of packs per capita by state.

  ggplot(Cigarette, aes(x = factor(state), y = packpc)) + geom_boxplot()

 # MN- Minnesota has the highest.UT-Utah has the lowest.

  cigmean<-Cigarette%>% group_by (state)%>% summarise(mean = mean(packpc))%>% arrange(mean)
  
  cigmean2<-Cigarette%>% group_by (state)%>% summarise(mean = mean(packpc))%>% arrange(desc(mean))
  
 #Find the median over all the states of the number of packs per capita for each year

  cigmed<-Cigarette %>% group_by (state)%>% summarise(median = median(packpc))


 #Plot this median value for the years from 1985 to 1995

  CigmedYear<-Cigarette%>% group_by (year)%>% summarise(median = median(packpc))

   unique(Cigarette$year)

    ggplot(CigmedYear, aes(x = year, y = median)) + geom_point()

# Cigarette usage has decreased from 1985 to 1995

 # Create a scatter plot of price per pack vs number of packs per capita for all states and years.

  ggplot(Cigarette,aes(x= cpi, y= packpc )) + geom_point() + geom_smooth(method=lm)

   cor.test(Cigarette$cpi, Cigarette$packpc, method = "pearson", use="complete.obs" )

# Negatively correlated 
 # The best fit line goes in a downward trend and the varibales are going into opposite directions
  # significantly corralated 

 # Change your scatter plot to show the points for each year in a different color. 

  ggplot(Cigarette, aes(x= cpi, y= packpc, color= year )) + geom_point() + geom_smooth(method=lm)

 # The relationship between price per pack and number of packs per capita decreases as the years progress 

  # Do a linear regression for these two variables.

   regress<- lm(packpc~cpi,Cigarette)
   summary(regress)

   # 16% variability is explained 


  #Create an adjusted price for each row


   AdjPrice<- Cigarette %>% mutate(packpc= avgprs/cpi)

 #re-do your scatter plot- adjusted price

  ggplot(AdjPrice, aes(x= cpi, y= packpc, color= year )) + geom_point() + geom_smooth(method=lm)

   #linear regression using this adjusted price.


  regress2<- lm(packpc~cpi,AdjPrice)
  summary(regress2)

      # Create a data frame with just the rows from 1985
   pkfrom1985<-Cigarette %>% filter(year==1985)   
      
   pk1985subset<-pkfrom1985[1:48,] 
   
      # Create a second data frame with just the rows from 1995.
   pkfrom1995<-Cigarette %>% filter(year==1995) 
   pk1995subset<-pkfrom1995[1:48,] 

 # Use a paired t-test for the difference in number of packs per capita in 1985 and 1995.

t.test(pk1985subset$packpc,pk1995subset$packpc, paired= TRUE)


 #What is the relationship between the taxes compared to per pack for fiscal year in cents and  average price per pack during fiscal year in cents

ggplot(Cigarette, aes(x= taxs, y= avgprs, color= year )) + geom_point() + geom_smooth(method=lm)

# Taxes increase each fiscal year  

  # What is the linear regression and variability

TAPregress<- lm(avgprs~taxs,Cigarette)
summary(TAPregress)

# 72% variability is explained 

#Adjust the price 

AdjPrice2<- Cigarette %>% mutate(packpc= avgprs/taxs )


ggplot(AdjPrice2, aes(x= taxs, y= avgprs, color= year )) + geom_point() + geom_smooth(method=lm)

