library("ggplot2")
library("dyplr")
library("gapminder")
levels(gapminder$country)


countries<- c("Costa Rica", "Mexico", "Jamaica", "Haiti","Trinidad and Tobago")


gm_Countries <- gapminder %>% filter(country %in% c("Costa Rica", "Mexico", "Jamaica", "Haiti","Trinidad and Tobago"))%>%select(country, year, lifeExp, gdpPercap)



gm_CountriesGDP <- gapminder %>% filter(country %in% c("Costa Rica", "Mexico", "Jamaica", "Haiti","Trinidad and Tobago"))%>%select(country, year, gdpPercap)
gm_Countrieslife <- gapminder %>% filter(country %in% c("Costa Rica", "Mexico", "Jamaica", "Haiti","Trinidad and Tobago"))%>%select(country, year, lifeExp)


ggplot(gm_CountriesGDP, aes(x = year, y = gdpPercap, color = country)) +
  geom_line() + geom_point(aes(size = gdpPercap)) +
  ylab("GDP") + ggtitle(" GDP in Five Countries")

ggplot(gm_Countrieslife, aes(x = year, y = lifeExp, color = country)) +
  geom_line() + geom_point(aes(alpha = year,size = lifeExp)) +
  ylab("lifeExp") + ggtitle(" LifeExp in Five Countries")

gm_medians1 <- gapminder %>% group_by(year) %>% summarise(life_med = median(lifeExp))

ggplot(gm_medians1, aes(x = year, y = life_med, color = year)) +
  geom_line() + geom_point(aes(size = life_med)) +
  ylab("life_med") + ggtitle(" Median LifeExp in all countries in years")

install.packages("gridExtra")
library("gridExtra")


life_exp5 <-ggplot(gm_Countrieslife) + geom_line(aes(x = year, y = lifeExp, color = country)) + ggtitle("LifeExp in Five countries" )
life_Med_all<- ggplot(gm_medians1) + geom_line(aes(x = year, y = life_med, color = year)) +
  ylab("Life Expectancy") + ggtitle(" Median Life Expectancy in all Years")
grid.arrange(life_exp5, life_Med_all, ncol = 1)













